package com.order;

public class ItalianKitchen implements Kitchen {

	@Override
	public String prepareFood(String order) {
		return (order  + " from italian kitchen is ready");
		
	}

}
