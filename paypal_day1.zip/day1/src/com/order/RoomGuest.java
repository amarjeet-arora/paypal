package com.order;

public class RoomGuest {
	public static void main(String[] args) {
		RoomService rs= new RoomService(new IndianKitchen());
		RoomService rs2= new RoomService(new ItalianKitchen());
		System.out.println(rs.takeOrderfromGuest("DOSA"));
		System.out.println(rs2.takeOrderfromGuest("PASTA"));
	}

}
