package com.order;

public class StaticDemo {
	
	static int a=3;
	static int b;

	
	static void calculate(int x) {
		
		System.out.println(x);
		System.out.println(a);
		System.out.println(b);
	}
	
	static {
		System.out.println("inside static block");
		
		b=a*4;
	}
	public static void main(String[] args) {
		 
calculate(5);
	}

}
