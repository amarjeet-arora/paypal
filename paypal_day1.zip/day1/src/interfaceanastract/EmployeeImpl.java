package interfaceanastract;

public class EmployeeImpl implements Employee {

	@Override
	public void addEmp(Emp emp) {

   System.out.println(emp);

		
	}

}
