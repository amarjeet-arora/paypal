package exceptiondemo3;

import java.io.FileNotFoundException;

public class Client {

	public static void main(String[] args) {
		Employee e= new Employee();
		
		
		EmployeeDao ed= new EmployeeDaoImpl();
		
		
		 try {
			ed.addEmp(e);
		} catch (DaoException e1) {
			// TODO Auto-generated catch block
System.out.println(e1.getMessage());		}
 	
		System.out.println("emp added");

	

}}
