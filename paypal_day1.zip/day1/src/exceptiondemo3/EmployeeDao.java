package exceptiondemo3;

import java.io.FileNotFoundException;

public interface EmployeeDao {
	
	
	public void addEmp(Employee e) throws DaoException;

}
