package exceptiondemo3;

public class DaoException extends Exception{

	public DaoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
