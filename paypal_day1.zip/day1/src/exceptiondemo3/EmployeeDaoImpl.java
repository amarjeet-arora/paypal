package exceptiondemo3;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public void addEmp(Employee e) throws DaoException {
		
		
		 
			try {
				FileOutputStream fos= new FileOutputStream("c:\\");
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();
				throw new DaoException("something went wrong.... try after sometime", e1);
			}
		 
		
		
		
	}

}
