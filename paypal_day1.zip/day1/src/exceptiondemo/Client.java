package exceptiondemo;

public class Client {

	public static void main(String[] args) {
		Employee e= new Employee();
		
		
		EmployeeDao ed= new EmployeeDaoImpl();
		
		
		ed.addEmp(e);
		System.out.println("emp added");

	}

}
