package exceptiondemo;

public interface EmployeeDao {
	
	
	public void addEmp(Employee e);

}
