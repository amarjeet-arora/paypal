package exceptiondemo;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public void addEmp(Employee e) {
		
		
		try {
			FileOutputStream fos= new FileOutputStream("c:\\");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
	}

}
