package day1com.pack;

public class EmployeeMain {

	public static void main(String[] args) {
	
		
		Employee emp= new Employee(101, "emp1", "Chennai");
		Employee emp2= new Employee(101, "emp1", "Chennai");
		
		System.out.println(emp.hashCode());
		System.out.println(emp2.hashCode());
		
		emp2=emp;
		System.out.println(emp2.hashCode());
		System.out.println(emp);
		
	}

}
