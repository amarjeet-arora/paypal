package exceptiondemo1;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public void addEmp(Employee e) throws FileNotFoundException {
		
		
		 
			FileOutputStream fos= new FileOutputStream("c:\\");
		 
		
		
		
	}

}
