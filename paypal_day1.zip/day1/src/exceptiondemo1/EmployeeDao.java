package exceptiondemo1;

import java.io.FileNotFoundException;

public interface EmployeeDao {
	
	
	public void addEmp(Employee e) throws FileNotFoundException;

}
