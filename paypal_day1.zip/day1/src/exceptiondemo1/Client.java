package exceptiondemo1;

import java.io.FileNotFoundException;

public class Client {

	public static void main(String[] args) {
		Employee e= new Employee();
		
		
		EmployeeDao ed= new EmployeeDaoImpl();
		
		
		try {
			ed.addEmp(e);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("emp added");

	}

}
