package collectiondemos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {

List<Employee> list= new ArrayList<Employee>();



		
list.add(new Employee(102, "emp2"));
list.add(new Employee(101, "emp1"));
list.add(new Employee(103, "emp3"));

list.add(0,new Employee(104, "emp4"));

Collections.sort(list,new NameComparator());
for(Object ob :list) {
	System.out.println(ob);
}

	}

}
