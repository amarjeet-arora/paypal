package collectiondemos;

import java.util.HashSet;
import java.util.TreeSet;

public class HashSetDemo {

	public static void main(String[] args) {

TreeSet<Employee> list = new TreeSet<Employee>();

list.add(new Employee(102, "emp2"));
list.add(new Employee(101, "emp1"));
list.add(new Employee(101, "emp1"));
list.add(new Employee(103, "emp3"));

list.add(new Employee(104, "emp4"));
for(Object ob :list) {
	System.out.println(ob);
}
	}

}
