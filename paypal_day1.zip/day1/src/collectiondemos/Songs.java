package collectiondemos;

public class Songs {
	
	private String title;
	private String artist;
	private String rating;
	private String singer;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getSinger() {
		return singer;
	}
	public void setSinger(String singer) {
		this.singer = singer;
	}
	public Songs(String title, String artist, String rating, String singer) {
		super();
		this.title = title;
		this.artist = artist;
		this.rating = rating;
		this.singer = singer;
	}

}
