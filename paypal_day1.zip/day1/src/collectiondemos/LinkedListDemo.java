package collectiondemos;

import java.util.*;

public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList<Employee> list= new LinkedList<Employee>();
		
		list.add(new Employee(102, "emp2"));
		list.add(new Employee(101, "emp1"));
		list.add(new Employee(103, "emp3"));
		
		list.addFirst(new Employee(105, "emp3"));

		Collections.sort(list,new NameComparator());
		for(Object ob :list) {
			System.out.println(ob);
		}

			}	
		
		

	}


