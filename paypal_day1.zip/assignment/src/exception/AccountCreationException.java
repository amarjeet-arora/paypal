package exception;

public class AccountCreationException extends CustomException{

	public AccountCreationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountCreationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AccountCreationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AccountCreationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
