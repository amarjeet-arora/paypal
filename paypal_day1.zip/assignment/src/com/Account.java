package com;

public class Account {
 int accNo;
 String accHolderName;
 public int getAccNo() {
	return accNo;
}
public void setAccNo(int accNo) {
	this.accNo = accNo;
}
public String getAccHolderName() {
	return accHolderName;
}
public void setAccHolderName(String accHolderName) {
	this.accHolderName = accHolderName;
}
public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}
float balance;
}
