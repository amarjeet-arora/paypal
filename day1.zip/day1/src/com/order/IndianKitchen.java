package com.order;

public class IndianKitchen implements Kitchen {

	@Override
	public String prepareFood(String order) {
		return (order + " from indian kitchen is ready");
		
	}

}
