package com.order;

public interface Kitchen {

	
	public String prepareFood(String order);
}
