package com.order;

public class RoomService {
	
	private Kitchen kitchen;

	public RoomService(Kitchen kitchen) {
		
		this.kitchen = kitchen;
	}
	
	public String takeOrderfromGuest(String order) {
		return kitchen.prepareFood(order);
	}

}
