package day1com.pack;

public class GarbageTest {

	public static void main(String[] args) {
		GarbageTest gt= new GarbageTest();
		
		
		
	System.out.println(gt.hashCode());
	gt=null;
	
	System.gc();
	System.out.println("called");

	}

	@Override
	protected void finalize() {
		 System.out.println("its called");
	}

}
