package day1com.pack;

public class StringDemo {

	public static void main(String[] args) {

// comparison b/w == and .equals
		
		/*
		 * String s1="sachin"; String s2= "Sachin";
		 * 
		 * String s3= new String("sachin");
		 * 
		 * String s4="saurav";
		 * 
		 * System.out.println(s1==s2); System.out.println(s1==s3);
		 * System.out.println(s1.equalsIgnoreCase(s2));
		 */

		StringBuilder sb= new StringBuilder("Welcome ");
		sb.append("to Java");
		System.out.println(sb);
		
		
		
	}

}
