package interfaceanastract;

public class Emp {
private int empId;
private String empName;

public Emp(int empId, String empName) {
	super();
	this.empId = empId;
	this.empName = empName;
}

@Override
public String toString() {
	return "Emp [empId=" + empId + ", empName=" + empName + "]";
}
}
