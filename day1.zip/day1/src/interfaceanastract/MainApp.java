package interfaceanastract;

public class MainApp {
public static void main(String[] args) {
	
	
	Employee e= new EmployeeImpl();
	
	Emp e1= new Emp(101, "emp1");
	
	e.addEmp(e1);
	
}
}
