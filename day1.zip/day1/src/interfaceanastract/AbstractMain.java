package interfaceanastract;

public class AbstractMain extends User{

	@Override
	public void addUser() {
	System.out.println("user is added");
		
	}
	
	public static void main(String[] args) {

		User am= new AbstractMain();
		am.addEmployee();
		am.addUser();
	}
	 

}
