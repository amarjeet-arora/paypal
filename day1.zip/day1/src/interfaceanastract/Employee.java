package interfaceanastract;

public interface Employee {
	public static final String EMP_NAME="admin";
	public void addEmp(Emp emp);
	

}
