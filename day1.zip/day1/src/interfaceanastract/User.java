package interfaceanastract;

public abstract class User {
	
	public User (){
		System.out.println("default");
	}
	
	public abstract void addUser();
	
	public void addEmployee() {
		System.out.println("employee is added");
	}

}
